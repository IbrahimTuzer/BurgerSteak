
import LoadingPage from "./LoadingPage";
import MyButton from "./MyButton";
import ScroolFood from "./ScroolFood";
import FlatBurger from "./FlatBurger"
import AddButton from "./AddButton";


export{

  
    LoadingPage,
    MyButton,
    ScroolFood,
    FlatBurger,
    AddButton,
    
}