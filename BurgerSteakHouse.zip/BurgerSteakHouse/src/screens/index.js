import WelcomePage from "./WelcomePage";
import LoginScreen from "./LoginScreen";
import Register from "./Register";
import Home from "./Home";
import DetailPage from "./DetailPage";


export{
    WelcomePage,
    LoginScreen,
    Register,
    Home,
    DetailPage,
}