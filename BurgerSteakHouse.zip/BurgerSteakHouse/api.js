import { db } from "./firebaseConfig";
import { collection, addDoc, getDocs, doc, updateDoc } from "firebase/firestore"; 



// *******************************************************************************

export const sendData = async(value) => { 
    try {
    const docRef = await addDoc(collection(db, "burgerList"), value);
    console.log("Document written with ID: ", docRef.id);
    } catch (e) {
    console.error("Error adding document: ", e);
    }
}

// *******************************************************************************




// *******************************************************************************

export const getData = async() =>{
    const arr = []
    const querySnapshot = await getDocs(collection(db, "burgerList"));
    querySnapshot.forEach((doc) => {
     // console.log(`${JSON.stringify(doc.id)} => ${JSON.stringify(doc.data())}`);
      const id = JSON.stringify(doc.id)
      const data = JSON.stringify(doc.data())
      arr.push({id:id, ...data}) 
    });
    console.log(arr)
    return arr
}

// *******************************************************************************






// *******************************************************************************

export const updateData = async()=>{
    const foodRef = doc(db, "burgerList", "j73He1aBbzPctrQiFQ5q");

    // Set the "capital" field of the city 'DC'
    await updateDoc(foodRef, {
        foodName: "Kebap"
    });
}


// *******************************************************************************